if(typeof console === 'undefined') { console = { log: function() { } }; }


var YDOM        = YAHOO.util.Dom;
var YEVENT      = YAHOO.util.Event;
var YELEMENT    = YAHOO.util.Element;
var YANIM       = YAHOO.util.Anim;
var YCALENDAR   = YAHOO.widget.Calendar;
var YSLIDER     = YAHOO.widget.Slider;

YSLIDER.prototype.verifyOffset=function(checkPos){var newPos=YAHOO.util.Dom.getXY(this.getEl());if(newPos){if(isNaN(this.baselinePos[0])){this.setThumbCenterPoint();this.thumb.startOffset=this.thumb.getOffsetFromParent(newPos);}if(newPos[0]!=this.baselinePos[0]||newPos[1]!=this.baselinePos[1]){this.thumb.resetConstraints();this.baselinePos=newPos;return false;}}return true;}; 
    
function FSForm(id) {
    
    this.id = id;
    
    this.scriptRequestCounter = 1;
    this.page = 1;
    this.lastPage = 1;
    
    this.checks       = [];
    this.logicFields  = [];
    this.calculations = [];
    this.calcFields   = [];
    this.calcFieldDefaults = {};
    this.useCalcFieldDefaults = false;
    
    this.validate = true;
    
    this.init = function() {

        if(this.lastPage > 1) {

            var scope = this;
            YEVENT.addListener('fsForm' + this.id, 'keypress', function(e) {                              

                if(e.keyCode != 13) return true;

                if(document.activeElement) {

                    if( document.activeElement.tagName == 'TEXTAREA')
                        return true;

                   /**
                    * The substring(5) reduces the element id to the Formstack field id
                    * e.g. field1509212 -> 1509212
                    */
                    scope.updateCalculations(document.activeElement.id.substring(5));
                    scope.checkLogic(document.activeElement.id.substring(5));
               }

                if( scope.page == scope.lastPage)
                    scope.submitForm();
				
		else scope.nextPage(scope.page);

                
                YAHOO.util.Event.preventDefault(e);
		YAHOO.util.Event.stopEvent(e);		
		return false;  

            });
        }

	//store calc field defaults	
	if(this.useCalcFieldDefaults){
            var fields = YDOM.getElementsByClassName('fsField');

            for (var j = 0; j < fields.length; j++) {

                var field = fields[j];
                var fieldType = field.type.toLowerCase();
                //console.log('Store Default: ' + field.id + ' = ' + field.value + ' - Disabled? ' + field.disabled);
            
		// Store intial values so we can reset the calculations based on the conditional logic
                if( !this.calcFieldDefaults[field.id]) {

                    if( (fieldType == 'radio' || fieldType == 'checkbox') && !field.disabled)
                        this.calcFieldDefaults[field.id] = field.checked

                     else if( fieldType == 'select-one' && !field.disabled)
                         this.calcFieldDefaults[field.id] = field.selectedIndex

                     else if(!field.disabled)
                         this.calcFieldDefaults[field.id] = field.value;
                }
            }
        }

        // Watch calc fields
        for (var i = 0; i < this.calcFields.length; i++) {
                
            var id = this.calcFields[i];
            
            var fields = this.getFieldsByName('field' + id);
            
            for (var j = 0; j < fields.length; j++) {
                
                var field = fields[j];
                var fieldType = field.type.toLowerCase();
/*
                // Store intial values so we can reset the calculations based on the conditional logic
                if( !this.calcFieldDefaults[field.id]) {

                    if( (fieldType == 'radio' || fieldType == 'checkbox') && !field.disabled)
                        this.calcFieldDefaults[field.id] = field.checked

                     else if( fieldType == 'select-one' && !field.disabled)
                         this.calcFieldDefaults[field.id] = field.selectedIndex

                     else if(!field.disabled)
                         this.calcFieldDefaults[field.id] = field.value;
                }
*/
                var evt = fieldType == 'radio' || fieldType == 'checkbox' ? 'click' : 'change';
                            
                YEVENT.addListener(field, evt, 
                    (function(id) {
                        return function() { 
                            this.updateCalculations(id);
                        }
                    })(id), this, true);

            }
            
            // Check for "other" field
            var other = YDOM.get('field' + id + '_othervalue');
            if (other) {
            
                YEVENT.addListener(other, 'change', 
                    (function(id, other) {
                        return function() {
                            YDOM.get('field' + id + '_other').checked = other.value != '';
                            this.updateCalculations(id);   
                        }
                    })(id, other), this, true);            
            }
        }

        // Watch logic fields
        for (var i = 0; i < this.logicFields.length; i++) {

            var id = this.logicFields[i];

            var fields = this.getFieldsByName('field' + id);
            
            for (var j = 0; j < fields.length; j++) {

                var field = fields[j];
                var fieldType = field.type.toLowerCase(); 
		var evt = fieldType == 'radio' || fieldType == 'checkbox' ? 'click' : 'change';

                YEVENT.addListener(field, evt,
                    (function(id) {
                        return function() {
                            this.checkLogic(id);
                        }
                    })(id), this, true);
            }
            
            /*
            //called in FSUtil.checkAll
            if(fieldType == 'checkbox'){
                var checkAll = document.getElementById('field' + id + '_all');
                if(checkAll != null){
                    YEVENT.addListener(checkAll, 'click',
                    (function(id) {
                        return function() {
                            this.checkLogic(id);
                        }
                    })(id), this, true);
                }
            }
           */

            // Check initial logic state
            this.checkLogic(id);
        }

        
        
        // Watch "other" fields
        var fields = YDOM.getElementsByClassName('fsOtherField', 'input');
        for (var i = 0; i < fields.length; i++) {
            
            var field = fields[i];
        
            YEVENT.addListener(field, 'change', function(e) {
                var field = YEVENT.getTarget(e);
                var id = field.id.split('_');
                YDOM.get(id[0]+'_other').checked = YDOM.get(field).value != '';
            }, this, true);
        }
        
        var fields = YDOM.getElementsByClassName('fsField');
        
        for (var i = 0; i < fields.length; i++) {
        
            var field = fields[i];

            YEVENT.addListener(field, 'focus', function(e) {
                var field = YEVENT.getTarget(e);
                this.focus(field, true); 
            }, this, true);
  
            YEVENT.addListener(field, 'blur', function(e) {
                var field = YEVENT.getTarget(e);
                this.focus(field, false); 
            }, this, true);
        }
        
        var fields = YDOM.getElementsByClassName('fsFieldConfirm');
        
        for (var i = 0; i < fields.length; i++) {
        
            var field = fields[i]; // Confirmation Field
            var f_id = field.id.replace('confirm_', ''); // ID of Main Field

            YEVENT.addListener(field, 'change', function(e) { // Confirmation Field Change
                var field = YEVENT.getTarget(e); // Confirmation Field

                var efield = document.getElementById(f_id);
                if(efield) {
                    this.checkFormat(efield);
                }
            }, this, true);
            
            /*
            YEVENT.addListener(document.getElementById(f_id), 'change', function(e) {
                var field = YEVENT.getTarget(e);
                var f2 = document.getElementById('confirm_' + f_id);
                console.log(field.value + " = " + f2.value);
                if(f2.value != '')
                    this.highlightField(f2, field.value != f2.value);   
                
            }, this, true);
            */
        }
        
        var els = YDOM.getElementsByClassName('fsCallout', 'div');
        for (var i = 0; i < els.length; i++) {
            
            var el = els[i];
            
            YDOM.setStyle(el, 'opacity', 0); 
            FSUtil.hide(el);
        }
        
        // Set initial calc values
        for (var i = 0; i < this.calculations.length; i++) {
        
            var calc = this.calculations[i];
         
            this.evalCalculation(calc);
        }
        
        // Get each calendar
        var divs = YDOM.getElementsByClassName('fsCalendar', 'div');
        for (var i = 0; i < divs.length; i++) {
            
            var div = divs[i];
            
            // Get the minimum and maximum years
            var id = div.id.match(/(\d+)/);id = id[1];
            var years = YDOM.get('field' + id + 'Y').options;
            var minyear = parseInt(years[1].value, 10);
            var maxyear = parseInt(years[years.length - 1].value, 10);
            
            // Fix for 2-digit years
            var curyear = new Date().getFullYear();            
            if (minyear < 100) minyear += minyear > curyear - 2000 ? 1900 : 2000;
            if (maxyear < 100) maxyear += 2000;
            
            // Render the calendar
            var calendar = new YCALENDAR(div.id, div.id, {
                mindate: '1/1/' + minyear,
                maxdate: '12/31/' + maxyear,
                close:true
            });
            calendar.render();
            
            // Set event handlers
            YEVENT.addListener(div.id + 'Link', 'click', calendar.show, calendar, true);
            calendar.beforeShowEvent.subscribe(this.calendarShow, calendar, true);    
            calendar.selectEvent.subscribe(this.calendarSelect, calendar, true);
        }
        
        // Find textareas with a max length
        var textareas = YDOM.getElementsByClassName('fsTextAreaMaxLength', 'textarea');
        for (var i = 0; i < textareas.length; i++) {
            
            var textarea = textareas[i];
            
            var id = textarea.id.match(/(\d+)/);
            id = id[1];
            
            // Get the counter
            var counter = YDOM.get('fsCounter' + id);
            var maxlength = 0;

            if(counter) {
                maxlength = parseInt(counter.innerHTML);
            }
            
            // Make sure we have a positive limit
            if (maxlength > 0) {
            
                // Bind keyup events to the limiter function
                YEVENT.addListener(textarea, 'keyup', 
                    (function(id, maxlength) { 
                        return function() {
                            this.textareaCharLimiter(id, maxlength); 
                        }
                    })(id, maxlength), this, true);
             
                // Add padding to the textarea
                YDOM.setStyle(textarea.id, 'paddingBottom', '24px');
                
                // Clear the counter value
                counter.innerHTML = '';
                FSUtil.show(counter);            
            }
        }
        
        // Find matrix fields that limit one per column
        var matrices = YDOM.getElementsByClassName('fsMatrixOnePerColumn', 'table');
        for (var i = 0; i < matrices.length; i++) {
        
            // Get all input fields in this matrix
            var inputs = matrices[i].getElementsByTagName('input');
            for (var j = 0; j < inputs.length; j++) {
            
                var fieldType = inputs[j].type.toLowerCase();
                if (fieldType == 'radio' || fieldType == 'checkbox') {
            
                    YEVENT.addListener(inputs[j], 'click',
                        (function(id) { 
                            return function() { 
                                this.checkMatrixOnePerColumn(id); 
                            }
                        })(inputs[j].id), this, true);
                }
            }
        }
        
        // Find sliders
        var sliders = YDOM.getElementsByClassName('fsSlider', 'input');
        for (var i = 0; i < sliders.length; i++) {
        
            var number = this.getNumberProperties(sliders[i]);
                
            // Only setup slider if we have a min/max value
            if (!isNaN(number.min) && !isNaN(number.max)) {
            
                var slider = YSLIDER.getHorizSlider(sliders[i].id + '-sliderbg', sliders[i].id + '-sliderthumb', 0, 100); 
                
                slider._fsobj    = this;
                slider._fsnumber = number;
                slider._fsfield  = sliders[i];
                slider._fsshow   = YDOM.get(sliders[i].id + '-slidervalue');
                
                // Set default value
                var defaultval = sliders[i].value != '' ? parseFloat(sliders[i].value) : number.min;
                if (isNaN(defaultval)) defaultval = number.min
                
                // Calculate the slider value
                // We don't do this for IE because of an issue where constraints are improperly set on multipage forms
                if (!/msie/i.test(navigator.userAgent) || /opera/i.test(navigator.userAgent)) {            
                    
                    var sliderval = Math.round((defaultval - number.min) / (number.max - number.min) * 100);
                    slider.setValue(sliderval, false, true, true);
                }
                    
                // Format the default value
                if (!isNaN(number.decimals))
                    defaultval = defaultval.toFixed(number.decimals);
                 
                // Update the real value
                sliders[i].value = defaultval;
                slider._fsshow.innerHTML = defaultval;

                // Subscribe to change event
                slider.subscribe('change', function(sliderval) {
                
                    // Calculate the real value
                    var realval = ((sliderval / 100) * (this._fsnumber.max - this._fsnumber.min)) + this._fsnumber.min;
                    realval = isNaN(this._fsnumber.decimals) ? Math.round(realval) : realval.toFixed(this._fsnumber.decimals);
                    if (realval == -0) realval = 0;
                        
                    // Update the real value
                    this._fsfield.value    = realval;
                    this._fsshow.innerHTML = realval;
                    
                    // Update calculations if applicable
                    var id = this._fsfield.id.match(/(\d+)/);id = id[1];
                    if (FSUtil.arrayIndexOf(this._fsobj.calcFields, id) >= 0)
                        this._fsobj.updateCalculations(id);

					//Update logic if applicable
					if (FSUtil.arrayIndexOf(this._fsobj.logicFields, id) >= 0) {
						this._fsobj.checkLogic(id);
					}       
					
                }, slider, true);
            }
        }
        
        // Check fields that need to be formatted a certain way
        var inputs  = [];
        var formats = ['fsFormatEmail', 'fsFormatPhoneUS', 'fsFormatPhoneUK', 'fsFormatPhoneAU', 
            'fsFormatPhoneXX', 'fsFormatZipUS', 'fsFormatZipCA', 'fsFormatZipUK', 'fsFormatZipAU', 
            'fsFormatNumber', 'fsFormatCreditCard'
        ];
        for (var formats_i = 0; formats_i < formats.length; formats_i++) {
            inputs = inputs.concat(YDOM.getElementsByClassName(formats[formats_i], 'input'));
        }
        
        for (var i = 0; i < inputs.length; i++) {
        
            // Format now
            this.checkFormat(inputs[i]);
            
            // Watch for changes and format onchange
            YEVENT.addListener(inputs[i], 'change',
                (function(field) { 
                    return function() { 
                        this.checkFormat(field); 
                    }
                })(inputs[i]), this, true);
        }
        
        // Update the progress bar
        this.updateProgress(1);
        
        // Fit table widths
        this.fitTableWidths(1);
        
        // Check for link on free forms
        if (!this.checkFreeLink())
            return;        
    };
    
    this.getFieldContainer = function(field) {

        var container = field;
        
        while (container && container.tagName.toLowerCase() != 'body') {
        
            if (YDOM.hasClass(container, 'fsFieldCell'))
                return container;
                
            container = container.parentNode;
        }
        
        return;
    };
    
    this.focus = function(field, focus) {
    
        // Don't run this in IE6 because of potential issues with Google Toolbar 
        if (/MSIE 6/i.test(navigator.userAgent)) return;
    
        var container = this.getFieldContainer(field);
        
        if (!container)
            return;
            
        if (focus) {
            
            YDOM.addClass(container, 'fsFieldFocused');                
            this.showCallout(container,true);        
        }
        else {
        
            YDOM.removeClass(container, 'fsFieldFocused');
            this.showCallout(container,false);
        }
    };

    this.showCallout = function(field,show) {

        var container = this.getFieldContainer(field);
        var callouts = YDOM.getElementsByClassName('fsCallout', 'div', container);
        
        if (!callouts.length)
            return;
            
        var callout = callouts[0];
            
        if (show) {
        
            // reposition, based on the field
            var fieldPosition = YDOM.getXY(field);
            var fieldHeight = FSUtil.getHeight(field);
            var fieldWidth = FSUtil.getWidth(field);

            YDOM.setStyle(callout, 'opacity', 0);
            YDOM.setStyle(callout, 'top', (fieldPosition[1]) + fieldHeight + 'px');
            YDOM.setStyle(callout, 'left', (fieldPosition[0] + 50) + 'px');
            YDOM.setStyle(callout, 'marginTop', '25px');
            
            FSUtil.show(callout);
            
            var myAnim = new YAHOO.util.Anim(callout, { 
                marginTop: {to: 0},
                opacity: {to: 1} 
                }, .5, YAHOO.util.Easing.easeOut);
           myAnim.animate();

        } 
        else {

            var myAnim = new YAHOO.util.Anim(callout, { 
                opacity: {to: 0} 
                }, .5, YAHOO.util.Easing.easeOut);
            myAnim.onComplete.subscribe(function() {FSUtil.hide(callout)} );
            myAnim.animate();
        }
    };

    this.fadeCallout = function(callout) {

        var steps = 15;
        var interval = 20;
        var show = YDOM.hasClass(callout, 'fsCalloutShowing');
        var opacity = YDOM.getStyle(callout,'opacity');
        var margin = YDOM.getStyle(callout,'marginTop').split('px')[0];
        var target = this;
        
        if (show) {
        
            opacity += (1 / steps);
            margin -= (25 / steps);
            
            if (opacity >= 1)
                opacity = 1;
            else
                setTimeout(function() {target.fadeCallout(callout);},interval);
                
            if (margin <= 0)
                margin = 0;
   
        } else {
        
            opacity -= (1 / steps);
            
            if (opacity <= 0) {
            
                opacity = 0;
                FSUtil.hide(callout);
            
            } else {
            
                setTimeout(function() {target.fadeCallout(callout);},interval);
            } 

        }

        YDOM.setStyle(callout, 'opacity', opacity);
        YDOM.setStyle(callout, 'margin-top', margin+'px');
    };

    this.checkRequired = function(page) {
        if(!this.validate || location.search.indexOf('no_req') >= 0)
            return true;

        // Remove the error message if one exists
        this.clearError(page);

        var showError = false;
        var skip = [];

        // Iterate over each field on the page
        var fields = YDOM.getElementsByClassName('fsField', '', 'fsPage' + this.id + '-' + page);
        for (var i = 0; i < fields.length; i++) {

            var field = fields[i];

            if (this.fieldIsVisible(field) && FSUtil.arrayIndexOf(skip, field.id) == -1) {

                var pass = true;

                // First check required fields for a value
                if (YDOM.hasClass(field, 'fsRequired')) {

                    var pFieldName = field.name.substr(0, field.name.indexOf('-'));
                    var pMatrix = document.getElementById('matrix-' + pFieldName);
                    if(pMatrix != null){

                        var inputs = pMatrix.getElementsByTagName('input');
                        var columns = new Array(false);

                        for (var j = 0; j < inputs.length; j++) {

                            hasRadio = false;
                            var fieldType = inputs[j].type.toLowerCase();
                            if (fieldType == 'radio' || fieldType == 'checkbox') {
                                if(fieldType == 'radio'){
                                    hasRadio = true;
                                    pass = this.checkValue(field);
                                }
                                
                                var col = parseInt(inputs[j].id.substr(inputs[j].id.lastIndexOf("-") + 1))-1;

                                if(columns[col] == null)
                                    columns[col] = false;

                                if(inputs[j].checked){
                                    columns[col] = true;
                                }
                            }
                        }


                        if(YDOM.hasClass(pMatrix, 'fsMatrixOnePerColumn')){
                            pass = true;
                            for(var c = 0; c < columns.length; c++){
                                if(columns[c] == false)
                                    pass = false;
                            }
                        }else if(!hasRadio){
                            pass = false;
                            for(var c = 0; c < columns.length; c++){
                                if(columns[c] == true){
                                    pass = true;
                                    break;
                                }
                            }
                        }

                        if(pass == false)
                            this.highlightField(field, true);

                    }else{
                        pass = this.checkValue(field);
                    }

                    if (!pass) {

                        showError = true;

                        // If this is an address field and we already know it's failed,
                        // skip the zip code so we don't test formatting
                        if (YDOM.hasClass(field, 'fsFieldAddress')) {
                            var id = field.id.split('-');id = id[0];
                            skip.push(id + '-zip');
                        }
                    }
                }

                // Now test file upload
                if (pass && YDOM.hasClass(field, 'fsUpload')) {

                    pass = this.checkUpload(field);
                    if (!pass) showError = true;
                }

                // If we don't already have an error, test format
                if (pass) {

                    pass = this.checkFormat(field);
                    if (!pass) showError = true;
                }
            }
        }

        if (showError) {

            this.showError( YDOM.get('requiredFieldsError') ?
                YDOM.get('requiredFieldsError').innerHTML : 'Please fill in a valid value for all required fields');
            return false;
        }

        return true;
    };
    
    
    this.checkValue = function(field) {

        var bad = false;
        
        switch (field.type.toLowerCase()) {
            case 'text':
            case 'password':
            case 'textarea':
            case 'file':
			case 'email':
			case 'tel':
            
                if (YDOM.hasClass(field, 'fsFieldName')) {
                
                    var id = field.id.split('-');id = id[0];
                    
                    bad = !YDOM.get(id + '-first').value.match(/\S/) ||  
                          !YDOM.get(id + '-last').value.match(/\S/);
                }
                else if (YDOM.hasClass(field, 'fsFieldAddress')) {
                
                    var id = field.id.split('-');id = id[0];
                    
                    bad = !YDOM.get(id + '-address').value.match(/\S/) || 
                          !YDOM.get(id + '-city').value.match(/\S/)    || 
                          !YDOM.get(id + '-zip').value.match(/\S/);
                    
                    if (!bad) {
                        var state = YDOM.get(id + '-state');
                        
                        if (state.type.toLowerCase() == 'select-one')
                            bad = !state.options[state.selectedIndex].value.match(/\S/);
                        else
                            bad = !state.value.match(/\S/);
                    }
                    
                    if (!bad) {
                        var country = YDOM.get(id + '-country');
                        if (country && !country.options[country.selectedIndex].value.match(/\S/)){
                            bad = true;
                        }
                    }
                }
                else {
                    bad = !field.value.match(/\S/);
                }
                
                break;
                
            case 'select-one':
                bad = field.selectedIndex < 0 || !field.options[field.selectedIndex].value.match(/\S/);
                break;
                
            case 'select-multiple':
                bad = true;
                var options = field.options;
                for (var j = 0; j < options.length; j++) {
                    if (options[j].selected && options[j].value.match(/\S/))
                        bad = false;
                }
                break;
                
            case 'radio':
            case 'checkbox':
                bad = true;
                var inputs = document.getElementsByName(field.name);
                for (var j = 0; j < inputs.length; j++) {
                    if (inputs[j].checked)
                        bad = false;
                }
            break;
        }
        
        if (bad) this.highlightField(field, true);
        
        return !bad;
    };
    
    this.checkFormat = function(field) {
        
        var hasFormat = false;
    
        // Only check format if there's a value
        if (field.value != '') {
            
            if (YDOM.hasClass(field, 'fsFormatEmail')) {
                
                hasFormat = true;
            
                if (!field.value.match(/^\s*\S+\@[\w\-\.]+\.\w+\s*$/)) {
                    this.highlightField(field, true);
                    return false;
                }

                var cfield = document.getElementById('confirm_' + field.id);
                if(cfield && cfield.value != field.value) {
                    this.highlightField(field, true);
                    return false;
                }else if(cfield){
                    this.highlightField(field, false);
                }
            }
            
            else if (
                YDOM.hasClass(field, 'fsFormatPhoneUS') ||
                YDOM.hasClass(field, 'fsFormatPhoneUK') ||
                YDOM.hasClass(field, 'fsFormatPhoneAU')
            ) {
            
                hasFormat = true;
            
                // Remove anything besides numbers or "x"
                var val = field.value.toLowerCase().replace(/[^\dx]/g, '');
                
                // Look for an extension
                var ext = '';
                if (val.indexOf('x') >= 0) {
                
                    // Split the extension from the number
                    var parts = val.split('x');
                    val = parts[0];
                    ext = parts[1];
                }
                
                // Remove any leading 1
                if (val.charAt(0) == '1')
                    val = val.substr(1, val.length - 1);
                    
                if (YDOM.hasClass(field, 'fsFormatPhoneUS')) {               
                                                
                    // Error if it isn't 10 digits
                    if (val.length != 10) {
                        this.highlightField(field, true);
                        return false;
                    }
                
                    // Format 
                    field.value = '(' + val.substr(0, 3) + ') ' + val.substr(3, 3) + '-' + val.substr(6, 4);                    
                }
                else if (YDOM.hasClass(field, 'fsFormatPhoneUK')) {
                                
                    // Remove +44
                    if (val.substr(0, 2) == '44') {
                        
                        val = val.substr(2, val.length - 2);
                        if (val.charAt(0) != '0')
                            val = '0' + val;
                    }
                
                    // Error if it doesn't start with "0" or isn't 10 or 11 digits
                    if (val.charAt(0) != '0' || (val.length != 10 && val.length != 11)) {
                        this.highlightField(field, true);
                        return false;
                    }
                    
                    // 01x1 xxx xxxx, 011x xxx xxxx, 08xx xxx xxxx
                    if (
                        (val.charAt(1) == '1' && (val.charAt(2) == '1' || val.charAt(3) == '1')) ||
                        (val.charAt(1) == '8')
                    ) {                    
                    
                        field.value = val.substr(0, 4) + ' ' + val.substr(4, 3) + ' ' + val.substr(7, val.length - 7);
                    }
                    
                    // 02x xxxx xxxx, 03x xxxx xxxx, 05x xxxx xxxx
                    else if (val.charAt(1) == '2' || val.charAt(1) == '3' || val.charAt(1) == '5') {
                    
                        field.value = val.substr(0, 3) + ' ' + val.substr(3, 4) + ' ' + val.substr(7, val.length - 7);
                    }
                    
                    // 0xxxx xxxxxx
                    else {
                    
                        field.value = val.substr(0, 5) + ' ' + val.substr(5, val.length - 5);
                    }
                }            
                else if (YDOM.hasClass(field, 'fsFormatPhoneAU')) {
                
                    // Remove +61
                    if (val.substr(0, 2) == '61') {
                        
                        val = val.substr(2, val.length - 2);
                        if (val.charAt(0) != '0')
                            val = '0' + val;
                    }
                
                    // Error if it doesn't start with "0" or isn't 10 digits
                    if (val.charAt(0) != '0' || val.length != 10) {
                        this.highlightField(field, true);
                        return false;
                    }
                    
                    // Format
                    field.value = '(' + val.substr(0, 2) + ') ' + val.substr(2, 4) + ' ' + val.substr(6, 4);  
                }
                
                if (ext.length)
                    field.value += ' x' + ext;
            }
            
            else if (YDOM.hasClass(field, 'fsFormatPhoneXX')) {
            
                hasFormat = true;
            
                // Just make sure we have at least 3 consecutive numbers somewhere
                if (! /\d{3,}/.test(field.value)) {
                    this.highlightField(field, true);
                    return false;
                }
            }
            
            else if (YDOM.hasClass(field, 'fsFormatZipUS')) {
            
                hasFormat = true;
                
                // Trim whitespace
                var val = field.value.replace(/^\s+/, '').replace(/\s+$/, '');
            
                // Make sure it validates
                if (!val.match(/^\d{5}(?:\-\d{4})?$/)) {                
                    this.highlightField(field, true);
                    return false;
                }
                
                field.value = val;
            }
            else if (YDOM.hasClass(field, 'fsFormatZipCA')) {
            
                hasFormat = true;
                
                // Trim whitespace
                var val = field.value.replace(/^\s+/, '').replace(/\s+$/, '').replace(/\s{2,}/, ' ').toUpperCase();
                
                // Add a space if one isn't there                
                if (val.length == 6 && !val.match(/\s/))
                    val = val.substr(0, 3) + ' ' + val.substr(3, 3);
                
                // Make sure it validates
                if (!val.match(/^[A-Z]\d[A-Z] \d[A-Z]\d$/)) {                
                    this.highlightField(field, true);
                    return false;
                }
                
                field.value = val;
            }
            else if (YDOM.hasClass(field, 'fsFormatZipUK')) {
            
                hasFormat = true;
                
                // Trim whitespace
                var val = field.value.replace(/^\s+/, '').replace(/\s+$/, '').replace(/\s{2,}/, ' ').toUpperCase();
                
                // Add space if one doesn't exist
                if (!val.match(/\s/)) {
                    val = val.substr(0, val.length - 3) + ' ' + val.substr(val.length - 3, 3);
                }
                                
                // Make sure it validates (see http://en.wikipedia.org/wiki/Postal_codes_in_the_United_Kingdom#Validation)
                if (!val.match(/^[A-Z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}$/)) {                
                    this.highlightField(field, true);
                    return false;
                }
                
                field.value = val;
            }
            else if (YDOM.hasClass(field, 'fsFormatZipAU')) {
            
                hasFormat = true;
                
                // Trim whitespace
                var val = field.value.replace(/^\s+/, '').replace(/\s+$/, '').toUpperCase();
                
                // Make sure it validates
                if (!val.match(/^\d{4}$/)) {                
                    this.highlightField(field, true);
                    return false;
                }
                
                field.value = val;
            }
            else if (YDOM.hasClass(field, 'fsFormatNumber')) {
            
                hasFormat = true;
            
                // Get a float value
                var val = parseFloat(field.value.replace(/[^\d\.\-]/g, ''));
                
                // Error if not a number
                if (isNaN(val)) {
                    this.highlightField(field, true);
                    return false;
                }
                
                var number = this.getNumberProperties(field);
                
                // Test minimum value
                if (!isNaN(number.min) && val < number.min) {
                    this.highlightField(field, true);
                    return false;
                }
                
                // Test maximum value
                if (!isNaN(number.max) && val > number.max) {                
                    this.highlightField(field, true);
                    return false;
                }
                
                // Format decimals
                if (!isNaN(number.decimals)) {
                    val = val.toFixed(number.decimals);
                }
                
                field.value = val;
            }
            else if (YDOM.hasClass(field, 'fsFormatCreditCard')) {
            
                hasFormat = true;
                
                // Get a numeric value
                var val = field.value.replace(/\D/g, '');
                
                // Calculate checksum  http://en.wikipedia.org/wiki/Luhn_algorithm               
                var checksum   = 0;
                var multiplier = 1;
                for (var i = val.length - 1; i >= 0; i--) {    
                
                    var calc = parseInt(val.charAt(i)) * multiplier;                    
                    
                    checksum += (calc > 9) ? calc - 9 : calc;          
                    
                    multiplier = multiplier == 1 ? 2 : 1;
                }
                
                if (checksum % 10 != 0)  {
                    this.highlightField(field, true);
                    return false;
                }
                
                // Validation info from http://en.wikipedia.org/wiki/Credit_card_numbers                
                
                // Visa
                if (val.match(/^4/)) { 
                
                    // Make sure card type is accepted and length is correct
                    if (!YDOM.hasClass(field, 'fsFormatCreditCardVisa') || 
                        (val.length != 13 && val.length != 16)) {
                        
                        this.highlightField(field, true);
                        return false;
                    }
                }
                
                // MasterCard
                else if (val.match(/^(?:51|52|53|54|55)/)) { 
                
                    // Check for valid length
                    if (!YDOM.hasClass(field, 'fsFormatCreditCardMasterCard') || 
                        val.length != 16) {
                        
                        this.highlightField(field, true);
                        return false;
                    }
                }
                
                // Discover
                else if (val.match(/^(?:6011|622|64|65)/)) { 
                
                    // Check for valid length
                    if (!YDOM.hasClass(field, 'fsFormatCreditCardDiscover') || 
                        val.length != 16) {
                        
                        this.highlightField(field, true);
                        return false;
                    }
                }
                
                // Amex
                else if (val.match(/^(?:34|37)/)) { 
                
                    // Check for valid length
                    if (!YDOM.hasClass(field, 'fsFormatCreditCardAmex') || 
                        val.length != 15) {
                        
                        this.highlightField(field, true);
                        return false;
                    }
                }
                
                // Diners
                else if (val.match(/^(?:300|301|302|303|304|305|36|54|55)/)) { 
                
                    // Check for valid length
                    if (!YDOM.hasClass(field, 'fsFormatCreditCardDiners') ||
                        (val.length != 14 && val.length != 16)) {
                        
                        this.highlightField(field, true);
                        return false;
                    }
                }
                
                // JCB
                else if (val.match(/^35/)) { 
                
                    // Check for valid length
                    if (!YDOM.hasClass(field, 'fsFormatCreditCardJCB') ||
                        val.length != 16) {
                        
                        this.highlightField(field, true);
                        return false;
                    }
                }
                
                else {
                    this.highlightField(field, true);
                    return false;
                }
                
                field.value = val;
            }
        }
        
        if (hasFormat) this.highlightField(field, false);
        
        return true;
    };

    this.checkUpload = function(field) {

        var pass = true;        
    
        // Get the valid file types
        var types = [];
        
        var classNames = field.className.split(/\s+/);
        for (var j = 0; j < classNames.length; j++) {
            
            var className = classNames[j];
                    
            if (/^uploadTypes-/.test(className)) {
                var m = className.split('-');
                types = m[1].split(',');
            }
        }
        
        // Make sure all types are lower case
        for (var j = 0; j < types.length; j++) {
            types[j] = types[j].toLowerCase();
        }
        
        if (FSUtil.arrayIndexOf(types, '*') < 0 && field && field.value != "" && this.fieldIsVisible(field)) {
            
            // Get the extension from the uploaded file
            var ext = field.value.match(/\.(\w+)$/);
            
            pass = ext && FSUtil.arrayIndexOf(types, ext[1].toLowerCase()) >= 0 ? true : false;
            
            // Highlight if it's bad
            if (!pass) {
                this.highlightField(field, true);
                var msg = YDOM.get('fileTypeAlert') ?
                    YDOM.get('fileTypeAlert').innerHTML : 'You must upload one of the following file types for the selected field:';
                alert(msg + types.join(', '));
            }
        }
        
        return pass;
    };
    
    this.showError = function(message) {       
        
        var error = document.createElement('div');
        error.id = 'fsError' + this.id;
        error.className = 'fsError';
        error.setAttribute("role","alert");
        error.innerHTML = message;
        YDOM.insertBefore(error, 'fsForm' + this.id);
        FSUtil.scrollTo('fsError' + this.id);
        
        //this.updateIframeHeight();
    };

    this.clearError = function(page) {
        
        // Get the required fields
        var fields = YDOM.getElementsByClassName('fsRequired', '', 'fsPage' + this.id + '-' + page);
        for (var i = 0; i < fields.length; i++)
            this.highlightField(fields[i], 0);
        
        // Get the upload fields
        var fields = YDOM.getElementsByClassName('fsUpload', 'input', 'fsPage' + this.id + '-' + page);
        for (var i = 0; i < fields.length; i++)
            this.highlightField(fields[i], 0);
        
        // Remove the error message if one exists
        var error = YDOM.get('fsError' + this.id);
        if (error) error.parentNode.removeChild(error);
    };

    this.highlightField = function(field, on) {
        
        var container = this.getFieldContainer(field);
        
        // Set the field background color
        if (on){

            YDOM.addClass(container, 'fsValidationError');
/*        
            labelErrs = YDOM.getElementsByClassName('fsValidationError');
//            labelErrs = YDOM.get('fsValidationError');

            something = labelErrs.getChildren('label');
//        var captcha_url = YDOM.get('fsForm' + this.id).action.replace(/index.php$/, 'captcha.php');


            //console.log(labelErrs);

            for (var i = 0; i < labelErrs.length; i++) {

                console.log(labelErrs[i]);
            }
*/
        }else{
         
            YDOM.removeClass(container, 'fsValidationError');
        }

    };

    this.checkSelected = function(fieldName, value) {

        var result = false;
        
        var elements = document.getElementsByName(fieldName);
        if (!elements.length) elements = document.getElementsByName(fieldName + '[]');
        
        for (var i = 0; i < elements.length; i++) {
                
            var element = elements[i];

            if (element.type == 'checkbox' || element.type == 'radio') {
                if (element.checked && element.value == value) result = true;
            }
            else if (element.type == 'select-one' || element.type == 'text') {

                result = element.value == value;
            }
            else if (element.type == 'select-multiple') {
                
                var options = element.options;
                for (var j = 0; j < options.length; j++) {
                    
                    var option = options[j];
                    
                    if (option.selected && option.value == value)
                        result = true;                    
                }
            }
        }
        
        return result;
    };

    this.checkLogic = function(id) {
                
        for (var i = 0; i < this.checks.length; i++) {
            
            var check = this.checks[i];
            
            if (FSUtil.arrayIndexOf(check.fields, id) >= 0) {
                
                var passed = check.bool == 'AND' ? true : false;
                
                for (var j = 0; j < check.checks.length; j++) {
                    
                    var fieldCheck = check.checks[j];
                    var test = false;

                    if( fieldCheck.condition == 'gt')
                        test = Number(YDOM.get('field' + fieldCheck.field).value) > Number(fieldCheck.option);

                    else if(fieldCheck.condition == 'lt')
                        test = Number(YDOM.get('field' + fieldCheck.field).value) < Number(fieldCheck.option);

                    else {

                        test = this.checkSelected('field' + fieldCheck.field, fieldCheck.option);
                        if (fieldCheck.condition == '!=') test = !test;
                    }

                    if (check.bool == 'AND') passed = passed ? test : false;
                    else passed = passed ? true : test;

                }

                var target = YDOM.get('fsCell' + check.target);
                
                // If the target is a section field, target the section wrapper
                if (YDOM.hasClass(target, 'fsSectionCell'))
                    target = YDOM.get('fsSection' + check.target);
                
                if (passed) {
                
                    if (check.action == 'Show'){
                        this.showFields(target);
                    }else{
                        this.hideFields(target);
                    }
                }
                else {
                
                    if (check.action == 'Show'){
                        this.hideFields(target);

                    }else{
                        this.showFields(target);
                    }
                }
            }
        }
    };

    this.showFields = function(cell) {
    
        var tags = ['input', 'textarea', 'select'];
        for (var i = 0; i < tags.length; i++) {
            
            var fields = cell.getElementsByTagName(tags[i]);
            
            for (var j = 0; j < fields.length; j++) {
            
                var field = fields[j];
            
                if (field.type != 'file')
                    field.disabled = false;
/*
                //this.updateCalculations(field.name.replace('field', ''));
                
                //
                // Evaluate the target calculation
                //
                var calc = this.getCalculationByTarget(field.name.replace('field', ''));
                if(calc != null) {
                    
                    // re-evaluate
                    this.evalCalculation(calc);
                }

                this.updateCalculations(field.name.replace('field', ''));
*/
            }
        }
                
        if (cell.tagName.toLowerCase() == 'table') {
            
            if (!FSUtil.visible(cell)) {
                FSUtil.show(cell);    
                this.updateTablePositionClasses(cell);
            }
        }
        else {
        
            YDOM.removeClass(cell, 'fsHiddenCell');
            FSUtil.show(YDOM.getAncestorByTagName(cell, 'tr'));

            var parentTable = YDOM.getAncestorByTagName(cell, 'table');
            if (!FSUtil.visible(parentTable)) {
                FSUtil.show(parentTable);
                this.updateTablePositionClasses(parentTable);
            }
            
            // Have to explicitly remove fsHidden cell from child TDs because of IE6/IE7+Matrix issue
            var matrixes = YDOM.getElementsByClassName('fsMatrix', 'table', cell);
            for (var matrixes_i = 0; matrixes_i < matrixes.length; matrixes_i++) {
            
                var matrixCells = matrixes[matrixes_i].getElementsByTagName('td');            
                for (var matrixCells_i = 0; matrixCells_i < matrixCells.length; matrixCells_i++) {
                    YDOM.removeClass(matrixCells[matrixCells_i], 'fsHiddenCell');
                }
            }
        }
        
    };

    this.hideFields = function(cell) {
    
        if (cell.tagName.toLowerCase() == 'table') {
    
            if (FSUtil.visible(cell)) {
                FSUtil.hide(cell);
                this.updateTablePositionClasses(cell);
            }
        }
        else {
            
            YDOM.addClass(cell, 'fsHiddenCell');
        
            var parentRow = YDOM.getAncestorByTagName(cell, 'tr');
            var cells = YDOM.getElementsByClassName('fsFieldCell', 'td', parentRow);
            
            // Try to figure out if we hide the parent row
            var hideRow = false;
            if (cells.length == 1) {
                hideRow = true;
            }
            else {           

                var hidden = YDOM.getElementsByClassName('fsHiddenCell', 'td', parentRow);
                
                if (hidden.length == cells.length)
                    hideRow = true;
            }
        
            if (hideRow) {
                             
                FSUtil.hide(parentRow);
                
                var parentTable = YDOM.getAncestorByTagName(cell, 'table');                
                var rows = YDOM.getElementsByClassName('fsFieldRow', 'tr', parentTable);
                                
                var show = false;
                
                for (var i = 0; i < rows.length; i++) {
                    if (FSUtil.visible(rows[i])) {
                        show = true;
                        break;
                    }
                }
                
                if (!show && FSUtil.visible(parentTable)) {
                    FSUtil.hide(parentTable);
                    this.updateTablePositionClasses(parentTable);
                }
            }
        }
        
        var tags = ['input', 'textarea', 'select'];
        for (var i = 0; i < tags.length; i++) {
            
            var fields = cell.getElementsByTagName(tags[i]);
            
            for (var j = 0; j < fields.length; j++) {
            
                var field = fields[j];

                //console.log('Hide Field: ' + field.id);

                if (field.type != 'file'){
                    field.disabled = true;
                    
		    if(this.useCalcFieldDefaults){
                        //
                        // Detect if the logic hid a value that is used in a calculation, if so
                        // we are going to reset it's value to the default and update the calculation.
                        //
                        var calc = this.getCalculation(field.name.replace('field', ''));
                        if(calc != null) {

                            //console.log('resetting ' + field.id + ' triggered by ' + cell.id);
                        
                            //
                            // Reset values
                            //
                            if(field.disabled){
                                if( i == 2)
                                    YDOM.get(field.id).selectedIndex = this.calcFieldDefaults[field.id] != null ? this.calcFieldDefaults[field.id] : 0;
                                else if(field.type == 'checkbox' || field.type == 'radio')
                                    YDOM.get(field.id).checked = this.calcFieldDefaults[field.id] != null ? this.calcFieldDefaults[field.id] : false;
                                else
                                    YDOM.get(field.id).value = this.calcFieldDefaults[field.id] != null ? this.calcFieldDefaults[field.id] : '';
                            }
                        
                            // re-evaluate
                            this.updateCalculations(field.name.replace('field', ''))
                        }
		    }
                    
                }
            }
        }
    };
    
    this.updateTablePositionClasses = function(table) {
        
        // Get the parent page
        var page = YDOM.getAncestorByTagName(table, 'div');
        if (!YDOM.hasClass(page, 'fsPage')) return;
        
        // Find all sections on the page
        var sections = YDOM.getElementsByClassName('fsSection', 'table', page);
        var first = -1;var last = -1;
        for (var i = 0; i < sections.length; i++) {
            
            if (FSUtil.visible(sections[i])) {
            
                if (first < 0) {
                    
                    first = i;
                    
                    YDOM.addClass(sections[i], 'fsFirstSection');
                    YDOM.removeClass(sections[i], 'fsMiddleSection');
                    YDOM.removeClass(sections[i], 'fsLastSection');
                }
                else {
                    YDOM.addClass(sections[i], 'fsMiddleSection');
                    YDOM.removeClass(sections[i], 'fsFirstSection');
                    YDOM.removeClass(sections[i], 'fsLastSection');
                }
                
                YDOM.removeClass(sections[last], 'fsSingleSection');
            
                last = i;
            }
        }
        
        if (last >= 0) {
                        
            YDOM.removeClass(sections[last], 'fsMiddleSection');
            
            if (last == first) {
                
                YDOM.addClass(sections[last], 'fsSingleSection');
                YDOM.removeClass(sections[last], 'fsFirstSection');
                YDOM.removeClass(sections[last], 'fsLastSection');
            }
            else {
                
                YDOM.addClass(sections[last], 'fsLastSection');
                YDOM.removeClass(sections[last], 'fsFirstSection');
            }
        }
    };

    this.getCalculation = function(id) {

        for (var i = 0; i < this.calculations.length; i++) {

            var calc = this.calculations[i];
            if (FSUtil.arrayIndexOf(calc.fields, id) >= 0) return calc;

        }
        return null;
    }

    this.getCalculationByTarget = function(target) {

        for (var i = 0; i < this.calculations.length; i++) {

            var calc = this.calculations[i];
            if (calc.target == target) return calc;

        }
        return null;
    }

    this.updateCalculations = function(id) {

        for (var i = 0; i < this.calculations.length; i++) {
            
            var calc = this.calculations[i];
            if (FSUtil.arrayIndexOf(calc.fields, id) >= 0)
                this.evalCalculation(calc);
        }
    };

    this.evalCalculation = function(calc) {

        var equation = calc.equation;
        var unit = '';
        
        for (var i = 0; i < calc.fields.length; i++) {
            
            var id = calc.fields[i];
        
            var regex = new RegExp('\\[' + id + '\\]', 'g');
            
            var val = 0;
            
            var fields = this.getFieldsByName('field' + id);
            var fLength = fields.length;

            for (var j = 0; j < fLength; j++) {
                
                var field = fields[j];

                //if(field.disabled){
                //    continue;
                //}
            
                var fieldValue;

                switch (field.type.toLowerCase()) {
                    case 'radio':
                    case 'checkbox':

                        if (field.value == 'Other' && YDOM.get(field.id + 'value')) {
                            fieldValue = YDOM.get(field.id + 'value').value;
                        }
                        else {                    
                            fieldValue = field.value;
                        }
                        
                        var v = this.getNumber(fieldValue);
                        if (field.checked && !isNaN(v)) val += v;
                        
                        break;
                        
                    case 'select-multiple':
                        var options = field.options;
                        for (var k = 0; k < options.length; k++) {
                            var v = this.getNumber(options[k].value);
                            if (options[k].selected && !isNaN(v)) {
                                //IE is cycling thru this four times, regardless of the number of values, etc. WTF?
				fieldValue = options[k].value;
                                val += v;
                            }
                        }
                        break;
                        
                    default:
                        
                        fieldValue = YDOM.get(field).value;
                        var v = this.getNumber(YDOM.get(field).value);
                        if (!isNaN(v)) val = v;
                }            
             
                if (fieldValue && fieldValue.indexOf('$') != -1)
                    unit = '$';

            }
            
            equation = equation.replace(regex, val);
            //equation's already doubled here before, so the issue is definitely with multiple select box.
            
        }
        
        var result = 0;
        try {result = eval(equation);}catch (e) {}
        
        // Get the destination field
        var field = YDOM.get('field' + calc.target);
        
        // Check if it's a number field
        if (YDOM.hasClass(field, 'fsFormatNumber')) {
        
            // Set the value and format accordingly
            field.value = result;
            this.checkFormat(field);
        }
        else {
        
            // Set the value explicitly
            field.value = unit + result.toFixed(2);
        }

        if( field.type == 'text') { 
            this.checkLogic(calc.target);
        }
        
        this.updateCalculations(calc.target);

    };

    this.getNumber = function(str) {

        if (!str) return;
        
        // Legacy for old forms with options like "value == label"
        if (str.indexOf(' == ') != -1) { 
            var values = str.split(' == ');
            str = values[1];
        }
        
        return parseFloat(str.replace(/[^\d\.\-]/g, ''));
    };

    this.previousPage = function(page) {

        var curr = YDOM.get('fsPage' + this.id + '-' + page);
        if (! curr) return;
        
        if (page <= 1) return;
        
        // Skip any empty pages
        var prevPage = page - 1;
        while (!this.pageIsVisible(prevPage) && prevPage > 1) {
            prevPage--;
        }
        
        var prev = YDOM.get('fsPage' + this.id + '-' + prevPage);
        
        FSUtil.hide(curr);
        FSUtil.show(prev);
        
        this.updateProgress(prevPage);
        
        this.clearError(page);
        
        FSUtil.hide('fsSubmit' + this.id);
        
        FSUtil.scrollTo(prev);
        
        this.fitTableWidths(prevPage);
        this.page--;
        //this.updateIframeHeight();
    };

    this.nextPage = function(page) {
        
        var curr = YDOM.get('fsPage' + this.id + '-' + page);
        if (! curr) return;
        
        if (page >= this.lastPage) return;
        
        if (this.checkRequired(page)) {
        
            // Skip any empty pages
            var nextPage = page + 1;
            while (!this.pageIsVisible(nextPage) && nextPage < this.lastPage) {            
                nextPage++;            
            }
            
            this.updateProgress(nextPage);
            
            var next = YDOM.get('fsPage' + this.id + '-' + nextPage);
        
            FSUtil.hide(curr);
            FSUtil.show(next);

            
            if (nextPage == this.lastPage)
                FSUtil.show('fsSubmit' + this.id);
            
            FSUtil.scrollTo(next);
            
            this.fitTableWidths(nextPage);
            this.page++;
            
            //this.updateIframeHeight();

            
            //check if this is a confirmation page (last page as well)
            if(nextPage == this.lastPage){

                if(window['cp' + this.id] != null){
                    window['cp' + this.id].parsePage();
                }
            }
            
        }
    };
    
    this.fitTableWidths = function(page) {
                
        // We don't need to fit table widths for anything except IE
        if (!/msie/i.test(navigator.userAgent) || /opera/i.test(navigator.userAgent))
            return;
                
        var pageID = 'fsPage' + this.id + '-' + page;
        
        // Get all tables
        var tables = YDOM.getElementsByClassName('fsTable', 'table', pageID);
            
        // Iterate over each and find the max width
        var max = 0;
        for (var i = 0; i < tables.length; i++) {
            
            var width = tables[i].scrollWidth;
            if (width > max) max = width;
        }

        // If we have a max adjust the form width
        if (max)
            YDOM.setStyle('fsForm' + this.id, 'width', max + 'px');
    };

    this.updateProgress = function(currentPage) {

        // if there's no progress meter, do nothing
        if (!YDOM.get('fsProgress' + this.id + '-' + currentPage))
            return;
            
        var pages = YDOM.getElementsByClassName('fsPage', 'div', 'fsForm' + this.id).length;

        // get rid of the progress, if you don't need it
        if (pages <= 1) {
        
            FSUtil.hide('fsProgress' + this.id + '-' + currentPage);
            return;
        }
        
        var progressBarContainer = YDOM.get('fsProgressBarContainer' + this.id + '-' + currentPage);
        var progressBar = YDOM.get('fsProgressBar' + this.id + '-' + currentPage);
        var totalWidth = 100;
        var ratio = currentPage / pages;
        
        if (ratio < 0)
            ratio = 0;
            
        if (ratio > 1)
            ratio = 1;
            
        var barWidth = (totalWidth * ratio) + 'px';
        
        YDOM.setStyle(progressBar, 'width', barWidth);        
    };

    this.pageIsVisible = function(page) {

        var hasVisible = false;

        // Check if there are any visible fields on that page
        var cells = YDOM.getElementsByClassName('fsFieldCell', 'td', 'fsPage' + this.id + '-' + page);
        for (var i = 0; i < cells.length; i++) {
            
            var cell = cells[i];

            if (FSUtil.visible(cell) && !YDOM.hasClass(cell, 'fsHiddenCell')) {

                // We think it's visible, but need to look for the section to make sure
                var section = YDOM.getAncestorByClassName(cell, 'fsSection');
                
                // If we didn't find an ancestor then the form wasn't in a section and is visible
                // If we have a section, check it's status
                if (!section || (FSUtil.visible(section) && !YDOM.hasClass(section, 'fsHiddenCell')))
                    hasVisible = true;                
            }
        }
        
        // Check for visible sections
        var sections = YDOM.getElementsByClassName('fsSection', 'table', 'fsPage' + this.id + '-' + page);
        
        for (var i = 0; i < sections.length; i++) {
            
            var section = sections[i];

            // If it's visible and isn't only a spacer
            if (FSUtil.visible(section) && !YDOM.hasClass(section, 'fsHiddenCell'))
                hasVisible = true;
                    
        }
        
        return hasVisible;
    };

    this.fieldIsVisible = function(field) {
                
        // Get the parent cell
        var cell = field.parentNode;
        while (cell && cell.tagName.toLowerCase() != 'body' && !YDOM.hasClass(cell, 'fsFieldCell')) {
            cell = cell.parentNode;
        }
        
        // Check if it's visible
        var visible = cell && cell.tagName.toLowerCase() != 'body' && FSUtil.visible(cell) && !YDOM.hasClass(cell, 'fsHiddenCell') ? true : false;
        
        // If it's not visible, return
        if (!visible) return false;
        
        // We think it's visible, but need to look for the section wrap to make sure
        var section = cell.parentNode;
        while (section && section.tagName.toLowerCase() != 'body' && !YDOM.hasClass(section, 'fsSection')) {
            section = section.parentNode;
        }
        
        // If we ran out of parents then the form wasn't in a wrap, use the visible status off the cell
        if (!section || section.tagName.toLowerCase() == 'body') return visible;
        
        // If we have a parent, return it's status
        return FSUtil.visible(section) && !YDOM.hasClass(section, 'fsHiddenCell');
    };

    this.checkForm = function() {
    
        // Check for required fields on the last page
        var res = this.checkRequired(this.lastPage);
        if (res) {
            
            var hidden_fields = [];
            
            // Get the required fields
            var fields = YDOM.getElementsByClassName('fsRequired', '', 'fsForm' + this.id);
            
            for (var i = 0; i < fields.length; i++) {
                
                var field = fields[i];
                
                // Check if it's visible
                if (! this.fieldIsVisible(field)) {
                    
                    if (field.id.indexOf('_') >= 0) {
                        var m = field.id.split('_');
                        hidden_fields.push(m[0]);
                    }
                    else {
                        hidden_fields.push(field.name);
                    }
                }
            }
                                    
            if (YDOM.get('hidden_fields' + this.id))
                YDOM.get('hidden_fields' + this.id).value = hidden_fields.join(',');
                
            // Check for captcha
            if (YDOM.get('captcha' + this.id)) {
            
                // Error if text wasn't entered for the captcha code
                if (YDOM.get('captcha_code_' + this.id).value == '') {
                    this.captchaError();                
                    return false;
                }            
            }

            return true;
        }
        else {
            return false;
        }
    };

    this.submitForm = function() {
        
        if (! this.checkForm()) return false;
        
        if (YDOM.get('captcha' + this.id)) {
            
            YDOM.get('fsSubmitButton' + this.id).disabled = true;
            
            var captcha_url = YDOM.get('fsForm' + this.id).action.replace(/index.php$/, 'captcha.php');
            
            // The web service call
            this.scriptRequest( captcha_url + '?action=test&v=2&captcha_code=' 
                + YDOM.get('captcha_code_' + this.id).value + '&form=' + this.id
                + '&fspublicsession=' + YDOM.get('session_id' + this.id).value + '&r=' + (new Date()).getTime() ); 
        }
        else {
            YDOM.get('fsForm' + this.id).submit();
        }
    };

    this.captchaError = function() {

        YDOM.addClass('captcha' + this.id, 'captchaError');
        
        FSUtil.scrollTo('captcha' + this.id);
    };
    
    this.reloadCaptcha = function(session_id) {
        
        var captcha_url = YDOM.get('fsForm' + this.id).action.replace(/index.php$/, 'captcha.php');
        
        YDOM.get('captcha_image_' + this.id).src = 
            captcha_url + '?fspublicsession=' + session_id + '&r=' + Math.random();
    };

    this.scriptRequest = function(req) {

        // Get the HEAD element
        var head = document.getElementsByTagName('head');
        
        // If we don't find one, just submit the form
        if (!head.length) {
            YDOM.get('fsForm' + this.id).submit();
            return;
        }
        
        head = head[0];
        
        // Create a SCRIPT element
        var script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('charset', 'utf-8');
        script.setAttribute('src', req);
        script.setAttribute('id', 'scriptRequest' + this.scriptRequestCounter);    
        head.appendChild(script);
        
        this.scriptRequestCounter++;
    };

    this.captchaTestCallback = function(data) {
        
        if (data.res == 'OK') 
            YDOM.get('fsForm' + this.id).submit();
        else 
            this.captchaError();
            
        YDOM.get('fsSubmitButton' + this.id).disabled = false;
    };

    this.calendarShow = function(type, args, calendar) {
        
        // Position the calendar
        var region = YDOM.getRegion(calendar.containerId + 'Link');
        if (region) {
            YDOM.setStyle(calendar.oDomContainer, 'top', region.top + 'px');
            YDOM.setStyle(calendar.oDomContainer, 'left', (region.left + 16) + 'px');
        }
        
    
        // Get the field ID
        var id = calendar.id.match(/(\d+)/);id = id[1];
        
        // Get the current date to use as the default
        var cur = new Date;

        // Get the selected month
        var monthSelect = YDOM.get('field' + id + 'M');
        var month = monthSelect && monthSelect.selectedIndex ? monthSelect.selectedIndex : cur.getMonth() + 1;
        
        // Get the selected day
        var daySelect = YDOM.get('field' + id + 'D');
        var day = daySelect && daySelect.selectedIndex ? daySelect.selectedIndex : cur.getDate();
        
        // Get the selected year
        var yearSelect = YDOM.get('field' + id + 'Y');
        var year = cur.getFullYear();
        if (yearSelect && yearSelect.selectedIndex) {            
            var year = parseInt(yearSelect.options[yearSelect.selectedIndex].value, 10);
            if (year < 100) year += 2000;            
        }
        
        // Select the date on the calendar
        calendar.select(month + '/' + day + '/' + year);
        calendar.setMonth(month - 1);
        calendar.setYear(year);
        calendar.render();
    };

    this.calendarSelect = function(type, args, calendar) {
        
        // Get the field ID
        var id = calendar.id.match(/(\d+)/);id = id[1];
        
        // Get the selected date
        var dates = args[0];
        var date = dates[0];
        var year = date[0], month = date[1], day = date[2];
        
        // Update the month
        var monthSelect = YDOM.get('field' + id + 'M');
        if (monthSelect)
            monthSelect.selectedIndex = month;
        
        // Update the day
        var daySelect = YDOM.get('field' + id + 'D');
        if (daySelect)
            daySelect.selectedIndex = day;
        
        // Update the year
        var yearSelect = YDOM.get('field' + id + 'Y');
        if (yearSelect) {
            for (var y = 1; y < yearSelect.options.length; y++) {
                
                // Get a 4-digit year
                var value = parseInt(yearSelect.options[y].value, 10);
                if (value < 100) value += 2000;
                
                if (value == year) {
                    yearSelect.selectedIndex = y;
                    break;
                }
            }
        }
        
        calendar.hide();
    };

    this.textareaCharLimiter = function(id, maxlength) {
 
        var textarea = YDOM.get('field' + id);
        var counter = YDOM.get('fsCounter' + id);
        var text = YDOM.get(textarea).value;
     
        // Truncate the text if over the max
        if (text.length > maxlength)
            textarea.value = text.substring(0, maxlength);
        
        // Update the counter
        counter.innerHTML = maxlength - YDOM.get(textarea).value.length;
        
        // Re-position the counter (accounts for changes in # digits of length and textarea resizes)
        var region = YDOM.getRegion(textarea.id);
        if (region) {
            YDOM.setStyle(counter.id, 'top', (region.bottom - FSUtil.getHeight(counter) - 5) + 'px');
            YDOM.setStyle(counter.id, 'left', (region.right - FSUtil.getWidth(counter) - 25) + 'px'); 
        }
    };   
        
    this.getFieldsByName = function(name) {
        
        var fields = new Array();
        
        var els = document.getElementsByName(name);
        if(els.length > 0){
            for (var i = 0; i < els.length; i++) {
                fields.push(els[i]);
            }
        }else{
            //IE bug will recognize [] as the same, thus doubling the fields being pushed
            var els = document.getElementsByName(name  + '[]');
            for (var i = 0; i < els.length; i++) {
                fields.push(els[i]);
            }
        }
        return fields;
    };
    
    this.saveIncomplete = function(page, email) {

        if (!confirm( YDOM.get('resumeConfirm') ?
                YDOM.get('resumeConfirm').innerHTML : 'Are you sure you want to leave this form and resume later?')
           )
            return;
        
        YDOM.get('incomplete' + this.id).value = 'true';
        YDOM.get('fsForm' + this.id).submit();
    };
    
    this.checkFreeLink = function() {
        
        // Check if the form has a class name indicating it's a free form
        var form = YDOM.get('fsForm' + this.id);
        if (!YDOM.hasClass(form, 'fsFormFree'))
            return true;
            
        var doc;
        
        // Get the embed type and the appropriate document object
        var type = YDOM.get('referrer_type' + this.id);
        switch (type.value) {
            
            case 'iframe':
                doc = window.parent.document;
                break;
                
            case 'js':
                doc = window.document;
                break;
                
            default:
                return true;
        }
        
        var found = false;
        
        // Make sure there is at least one link on the page to formstack.com or formspring.com
        // formspring.com is kept here for backwards compatability.
        var links = doc.getElementsByTagName('a');
        for (var i = 0; i < links.length; i++) {
            if ((links[i].href.indexOf('http://www.formspring.com/') == 0)
            ||  (links[i].href.indexOf('http://www.formstack.com/')  == 0)){

                found = true;
                break;
            }
        }
           
        if (found)
            return true;
        
        this.showError( YDOM.get('embedError') ?
            YDOM.get('embedError').innerHTML : 'There was an error displaying the form. Please copy and paste the embed code again.');
        FSUtil.hide(form);
        //this.updateIframeHeight();
        
        return false;
    };
    
    this.checkMatrixOnePerColumn = function(id) {
    
        // Split the ID into parts
        var ids = id.split('-');
        var fieldID = ids[0]; 
        var rowID   = ids[1]; 
        var colID   = ids[2];
        
        // Get all input fields in the matrix
        var inputs = YDOM.get('matrix-' + fieldID).getElementsByTagName('input');
        for (var i = 0; i < inputs.length; i++) {
        
            var re = new RegExp('^' + fieldID + '-\\d+-' + colID + '$');
        
            // Uncheck if it's a different field in the same column
            if (inputs[i].id != id && re.test(inputs[i].id))
                inputs[i].checked = false;
        }
    };
    
    this.getNumberProperties = function(field) {
    
        var number = {
            min:      NaN,
            max:      NaN,
            decimals: NaN
        };
        
        // Check classnames for min, max and decimal
        var classNames = field.className.split(/\s+/);
        for (var i = 0; i < classNames.length; i++) {
            
            var className = classNames[i];
            
            var match;
            
            if (match = className.match(/^fsNumberMin-([\-\d]+)/)) {                
                number.min = parseInt(match[1]);
            }
            else if (match = className.match(/^fsNumberMax-([\-\d]+)/)) {
                number.max = parseInt(match[1]);
            }
            else if (match = className.match(/^fsNumberDecimals-([\d]+)/)) {
                number.decimals = parseInt(match[1]);
            }
        }
        
        return number;
    };
    
    this.generatePrePopulateLink = function(){
        
        var link = document.location.href;
        
        var fields = YDOM.getElementsByClassName('fsField');
        for (var i = 0; i < fields.length; i++) {

            var field = fields[i];
            
            if(YDOM.hasClass(field, 'fsFormatCreditCard')) continue;
            
            val = this.getValue(field);
            
            if(val == null || val == '')
                continue;
            
            name = field.name != null? field.name : field.id;
            link += '&' + name + '=' + encodeURIComponent(val);
        }  
        
        document.getElementById('form' + this.id + 'PrePopulateLink').value = link;
        document.getElementById('form' + this.id + 'PrePopulateDiv').style.display = 'block';
    };
    
    this.copyFieldValue = function(from, to){
        var fields = YDOM.getElementsByClassName('fsField');
        for (var i = 0; i < fields.length; i++) {
            var field = fields[i];

            if(field.id.indexOf('field' + from) > -1){

                var ext = field.id.replace('field' + from, '');

                var fieldTo = document.getElementById('field' + to + ext) == null? document.getElementById('field' + to) : document.getElementById('field' + to + ext);

                if (fieldTo.type == 'radio' || fieldTo.type == 'checkbox') {
                    fieldTo.checked = field.checked;
                }
                else {
                    fieldTo.value = field.value;
                }
            }
        }
    };
    
    this.getValue = function(input){
        
        if(input.disabled) {

            return null;
        }
        else if (input.type == 'radio' || input.type == 'checkbox') {
            
            return input.checked ? input.value : null;
        }
        else if (input.type == 'select-one') {

            return input.options[input.selectedIndex].value;
                    
        }
        else return input.value;
        
    };
    
    this.dontValidate = function(link){
        this.validate = false;
        link.innerHTML = 'Not Validating';
    }
}


/* Utility methods to replace Prototype.js */    
function FSUtil() {}

FSUtil.checkAll = function(el) {

    var prefix = el.name.replace('_all', '_');

    var i = 1;
    var e;
    while(e = document.getElementById(prefix + i)) {

        e.checked = el.checked;
        i++;
    }
    
    form = document.getElementsByName('form');
    form = form[0];
    id = prefix.replace('field', '');
    id = id.replace('_', '');
    eval('form' + form.value + '.checkLogic(' + id + ')');
    eval('form' + form.value + '.updateCalculations(' + id + ')');
};

FSUtil.show = function(el) {
    
    YDOM.setStyle(el, 'display', '');
};

FSUtil.hide = function(el) {
    
    YDOM.setStyle(el, 'display', 'none');
};

FSUtil.visible = function(el) {
    
    return YDOM.getStyle(el, 'display') != 'none';
};
    
FSUtil.scrollTo = function(el) {
    
    window.scroll( YDOM.getX(el), YDOM.getY(el) );
};

FSUtil.getHeight = function(el) {

    var region = YDOM.getRegion(el);
    var height = region.bottom - region.top;
    return isNaN(height) ? 0 : height;
};

FSUtil.getWidth = function(el) {
    
    var region = YDOM.getRegion(el);
    var width = region.right - region.left;
    return isNaN(width) ? 0 : width;
};

FSUtil.arrayIndexOf = function(arr, item) {
    
    for (var i = 0; i < arr.length; i++)
        if (arr[i] == item) 
            return i;
        
    return -1;
};
